/*
 * This project demonstrates the difference between recursive and non-recursive methods for factorial and fibonacci
*/
package h10;


public class H10 {

    
    public static void main(String[] args) {
        
        System.out.println("Non recursive Factorial");
        for (int i=0; i<=10; i++)
            System.out.println("Factorial " + i + " equals " + factorial(i));
        System.out.println();
        System.out.println("Recursive Factorial");
        for (int i=0; i<=10; i++)
            System.out.println("Factorial " + i + " equals " + recFactorial(i));
        System.out.println();
        System.out.println("Non recursive Fibonacci");
        for (int i=0; i<=10; i++)
            System.out.println("The " + i + "th Fibonacci number is  " + fibonacci(i));
        System.out.println();
        System.out.println("Recursive Fibonacci");
        for (int i=0; i<=10; i++)
            System.out.println("The " + i + "th Fibonacci number is  " + recFibonacci(i));
    }//main 
        
    //non recursive factorial method
    public static int factorial(int i){
        int x = 1;
        while (i>1){
            x = x *i;
            i--;
        }
        return x;
    }
    //recursive factorial method
    public static int recFactorial(int i) {
        if (i == 0) {
            return 1;
        } 
        else {
            return i * recFactorial(i - 1);
        }
    }
    //non recursive fibonacci method
    public static int fibonacci(int i){
        if (i==0) return 0;
        if (i==1) return 1;
        int arr[] = new int[i+1];
            arr[0] = 0;
            arr[1] = 1; 
        for (int y = 2; y <= i; y++){
            arr[y] = arr[y-1] + arr[y-2]; 

        }
        return arr[i];
    }
    //recursive fibonacci method
    public static int recFibonacci(int i){
        if (i==0) return 0;
        if (i==1) return 1;
        return recFibonacci(i-1) + recFibonacci(i-2);

    }
    
    
}//class
    

