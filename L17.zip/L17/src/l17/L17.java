/*
 * this porgram makes use of the bubble sort method to sort a rectangle array based on its area. its print out the unsorted and sorted areas.
 * 
 */
package l17;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Rodrigo Mozo Jr
 */
public class L17 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //implement scanner 
        File inFile = new File("rectInput.txt");
        Scanner fileInput =null;
        
        try{
            fileInput = new Scanner(inFile);
        }
        catch (FileNotFoundException e)
        { System.out.println(e);
            
        }
        
        //rectangle array
        Rectangle[] arr = new Rectangle[10];
        
        
        int i =0;
        //scan the inputs
        while (fileInput.hasNext()){
            double length = fileInput.nextDouble();
            double width = fileInput.nextDouble();
            arr[i] = new Rectangle(length, width);
            i++;
        }
        
        //print out each rectangle's area using method
        System.out.println("Unsorted Areas:");
        printArea(arr);
        
        //visual line 
        for (int j = 0; j<15; j++){
            System.out.print("_ ");
            if (j==14){
                System.out.println();
                System.out.println();
            }
        }
        
        //bubble sort the array
        bubbleSort(arr);
        
        //print areas again
        System.out.println("Sorted Areas:");
        printArea(arr);
        
    }//main
    
    //print area method
public static void printArea(Rectangle[] arr){
    for(int j =0; j<arr.length; j++){ 
        System.out.println(arr[j].area());
    }
}
public static<T extends Comparable<T>> void bubbleSort(T[] arr) { 
        T temp;  
         for(int i=0; i < arr.length; i++){  
            for(int j=1; j < (arr.length-i); j++){  
              if(arr[j-1].compareTo(arr[j])>0){  
               //swap places if first value is higher than the second
               temp = arr[j-1]; //store the higher value as temp 
               arr[j-1] = arr[j]; //make both values the same
               arr[j] = temp;  //return the higher value to new swapped element in the array
              }                
          }  
       }
    }
}//class

