//this program simulates printing out stars in non-recursive and recursive methods
package recex;

//Rodrigo Mozo Jr

public class RecEx {

  
    public static void main(String[] args) {
        System.out.println("Non recursive methods");
        printRectangleStars(5,3);//length 5, height 3
        System.out.println();
        printTriangleStars(5);
        System.out.println();
        printTriangleStars2(6);
       System.out.println();
        printTriangleNumbers(6);
        System.out.println("Recursive methods");
        RecprintRectangleStars(5,3);//length 5, height 3
       System.out.println();
       RecprintTriangleStars(5);
       System.out.println();
        RecprintTriangleStars2(6);
        System.out.println();
        RecprintTriangleNumbers(6);
    }
    public static void printTriangleStars(int n)
    {
      for (int k = 1; k<=n; k++){
      for (int i = 0; i<k; i++){
          System.out.print("*");
      }
      System.out.println();
      }
    }
    public static void printTriangleStars2(int n)
    {
     for(int k = n; k>0;k--){
         for(int i =0; i<k; i++){
         System.out.print("*");
     }
         System.out.println();
     }   
    }
    
    public static void printTriangleNumbers(int n)
    {
     for(int k = n; k>0;k--){
         for(int i =1; i<=n -k+1; i++){
         System.out.print(i);
     }
         System.out.println();
     }    
    }
    public static void printRectangleStars(int len, int h)
    {
       for (int i = 0; i < h; i++) {
        for (int k = 0; k < len; k++) {
            System.out.print("*");
        }
        System.out.println();
    }  
    }
    public static void RecprintRectangleStars(int len, int h)
    {
      if (h == 0)return;
    for (int i = 0; i < len; i++)
    System.out.print("*");
    System.out.println();

    
    RecprintRectangleStars(len, h - 1);
}
    public static void RecprintTriangleStars(int n)
    {  
     if (n == 0)return;    
    RecprintTriangleStars(n - 1);

    for (int i = 0; i < n; i++)
    System.out.print("*");
    System.out.println();
}
    public static void RecprintTriangleStars2(int n)
    {
      if (n == 0)return;   
    for (int i = 0; i < n; i++)
    System.out.print("*");
    System.out.println();

    RecprintTriangleStars2(n - 1);
}
    public static void RecprintTriangleNumbers(int n)
    {
       if (n == 0) return;
    RecprintTriangleNumbers(n - 1);

    for (int i = 1; i <= n; i++)
    System.out.print(i);
    System.out.println();
}
}
