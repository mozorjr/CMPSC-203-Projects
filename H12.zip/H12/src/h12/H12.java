/*
 * this program can read lines from a file and then check recursively whether it is a palindrome
 * 
 */
package h12;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.File;

/**
 *
 * @author Rodrigo Mozo Jr
 */
public class H12 {

//method to remove white space and all punctuation by checking if each chracter is letter 
 public static String removeWS(String a)
 { 
  if (a.length()==0) return "";
  if (Character.isLetter(a.charAt(0))) return a.charAt(0) + removeWS(a.substring(1));
  return removeWS(a.substring(1));
 }
 //palindrome method to compare each beginning and ending character 
 public static boolean palindrome(String s) 
 {
    if (s.length()<= 1) return true;
    if (s.charAt(0) != s.charAt(s.length()-1)) return false;
    return palindrome(s.substring(1, s.length() - 1));
    }
 
    public static void main(String[] args) {
        //input file
        File f = new File("palin.txt");
        Scanner scnr = null;
        try{
        scnr = new Scanner(f);
    }
        catch (FileNotFoundException e)
{ System.out.println("File Not Found");
}
       int x = 1; //counter for each palindrome
       while (scnr.hasNext()){
       //scan the string, run it through remove white space method, convert it to lowercase, then check for plaindrome
       String a = scnr.nextLine();
       String s = removeWS(a);
       s = s.toLowerCase();
       if (palindrome(s)) {
           System.out.println(x+": "+a); 
           x++;
       }
       }
        
    }//main
    
}//class
