/*
 * This program creates 4 arrays of rectangles, circles, feetInches and fraction. It fills out the arrays using an input file and
   prints out each array. It then prompts the user to enter 2 of each class to find that specific index in its respective array using binary search.
 */
package h15;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Rodrigo Mozo Jr
 */
public class H15 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        File inFile = new File("BinarySearch.in");
        Scanner fileInput =null;
        
        try{
            fileInput = new Scanner(inFile);
        }
        catch (FileNotFoundException e)
        { System.out.println(e);
            
        }
        
        //create 4 arrays
        //circle array
        Circle[] arrC = new Circle[20];
        //fraction array
        Fraction[] arrF = new Fraction[24];
        //feetInches array
        FeetInches[] arrI = new FeetInches[16];
        //rectangle array
        Rectangle[] arrR = new Rectangle[12];
        
        //create loop to capture all input
        while(fileInput.hasNext()){

        // Input the lengths and widths for rectangles
        for (int i = 0; i < 12; i++) {
            double length = fileInput.nextDouble();
            double width = fileInput.nextDouble();
            arrR[i] = new Rectangle(length, width);
        }

        // Input the radii for circles
        for (int i = 0; i < 20; i++) {
            double radius = fileInput.nextDouble();
            arrC[i] = new Circle(radius);
        }

        // Input numerator/denominator pairs for fractions
        for (int i = 0; i < 24; i++) {
            int numerator = fileInput.nextInt();
            int denominator = fileInput.nextInt();
            arrF[i] = new Fraction(numerator, denominator);
        }

        // Input feet/inches pairs for FeetInches objects
        for (int i = 0; i < 16; i++) {
            int feet = fileInput.nextInt();
            int inches = fileInput.nextInt();
            arrI[i] = new FeetInches(feet, inches);
        }
        }
        //print out each array and print a line to make it easier to read
        System.out.println("Here are the Cricle objects: ");
       for(int i = 0; i<arrC.length; i++){
           System.out.println(arrC[i]);
       }
       System.out.println("---------------------------------------------------");
       System.out.println("Here are the Rectangle objects: ");
       for(int i = 0; i<arrR.length; i++){
           System.out.println(arrR[i]);
       }
        System.out.println("---------------------------------------------------");
       System.out.println("Here are the Fraction objects: ");
       for(int i = 0; i<arrF.length; i++){
           System.out.println(arrF[i]);
       }
       System.out.println("---------------------------------------------------");
        System.out.println("Here are the FeetInches objects: ");
       for(int i = 0; i<arrI.length; i++){
           System.out.println(arrI[i]);
       }
    //binary search 2 user created rectangle classes
    for (int i = 0; i < 2; i++) {
    System.out.println("Enter a rectangle class to binary search for: ");
    double length = scnr.nextDouble();
    double width = scnr.nextDouble();
    Rectangle rect = new Rectangle(length, width);
    int x = binarySearch(arrR, rect, 0, arrR.length - 1);
    System.out.println("Index of rectangle: " + x);
}
    //binary search 2 user created circle classes
    for (int i = 0; i < 2; i++) {
    System.out.println("Enter a circle class to binary search for: ");
    double radius = scnr.nextDouble();
    Circle cir = new Circle(radius);
    int x = binarySearch(arrC, cir, 0, arrC.length - 1);
    System.out.println("Index of circle: " + x);
}
    //binary search 2 user created fraction classes
    for (int i = 0; i < 2; i++) {
    System.out.println("Enter a fraction class to binary search for: ");
    int numerator = scnr.nextInt();
    int denominator = scnr.nextInt();
    Fraction frac = new Fraction(numerator, denominator);
    int x = binarySearch(arrF, frac, 0, arrF.length - 1);
    System.out.println("Index of fraction: " + x);
}
    //binary search 2 user created feetInches classes
    for (int i = 0; i < 2; i++) {
    System.out.println("Enter a feetInches class to binary search for: ");
    int feet = scnr.nextInt();
    int inches = scnr.nextInt();
    FeetInches feetI = new FeetInches(feet, inches);
    int x = binarySearch(arrI, feetI, 0, arrI.length - 1);
    System.out.println("Index of feetInches: " + x);
}
       
    }//main

//binary search for circle
public static int binarySearch(Circle[] arrC,Circle key, int low, int high)
    {
    int rangeSize = (high-low) + 1;
    int mid = (high+low)/2;
    if (key.compareTo(arrC[mid]) == 0) return mid;//found it, no further recursion needed
    else if(rangeSize==1) return -1;//not in array
    if (key.compareTo(arrC[mid]) < 0) return binarySearch(arrC, key, low, mid);
    else return binarySearch(arrC, key, mid+1, high);
    }
//binary search for rectangle
public static int binarySearch(Rectangle[] arrR,Rectangle key, int low, int high)
    {
    int rangeSize = (high-low) + 1;
    int mid = (high+low)/2;
    if (key.compareTo(arrR[mid]) == 0) return mid;//found it, no further recursion needed
    else if(rangeSize==1) return -1;//not in array
    if (key.compareTo(arrR[mid]) < 0) return binarySearch(arrR, key, low, mid);
    else return binarySearch(arrR, key, mid+1, high);
    }
//binary search for feetInches
public static int binarySearch(FeetInches[] arrI,FeetInches key, int low, int high)
    {
    int rangeSize = (high-low) + 1;
    int mid = (high+low)/2;
    if (key.compareTo(arrI[mid]) == 0) return mid;//found it, no further recursion needed
    else if(rangeSize==1) return -1;//not in array
    if (key.compareTo(arrI[mid]) < 0) return binarySearch(arrI, key, low, mid);
    else return binarySearch(arrI, key, mid+1, high);
    }
//binary search for fraction
public static int binarySearch(Fraction[] arrF,Fraction key, int low, int high)
    {
    int rangeSize = (high-low) + 1;
    int mid = (high+low)/2;
    if (key.compareTo(arrF[mid]) == 0) return mid;//found it, no further recursion needed
    else if(rangeSize==1) return -1;//not in array
    if (key.compareTo(arrF[mid]) < 0) return binarySearch(arrF, key, low, mid);
    else return binarySearch(arrF, key, mid+1, high);
    }

    
}//class
