/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package h15;

/**
 *
 * @author Rodrigo Mozo Jr
 */
public class FeetInches implements Comparable <FeetInches> {
    private int feet;
    private int inches;

    public FeetInches()
    {//write the code for the default constructor here
        feet = 0;
        inches = 0;
    }
    public FeetInches(int f, int i)
    { 
        feet = f + i/12;
        inches = i%12;

    }
    public void setFeet(int f){
        feet = f;

    }
    public void setInches(int i){
        feet = feet + i/12;
        inches = i%12;
    }
    public int getFeet(){
        return feet;
    }
    public int getInches(){
        return inches;
    }
    
    public int trueInches(){
        int a = this.feet*12;
        int b = this.inches + a;
        return b;
    }



    public String toString()
    {

        return " Feet: " + feet + "  Inches: " + inches ;
    }
    
    public int compareTo(FeetInches x){

           if(this.trueInches()>x.trueInches())return 1;
           if(this.trueInches()<x.trueInches()) return -1;
           else return 0;
       }
}
