/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package h15;

/**
 *
 * @author Rodrigo Mozo Jr
 */
public class Fraction implements Comparable <Fraction>{
    private int numerator;
       private int denominator;

        public Fraction()
        {
            numerator = 0;
            denominator=1;
        }
         public Fraction(int n, int d)
        {
           this.numerator = n;
           this.denominator = d;
           this.reduce();


        }

        public int getNumerator() {
            return numerator;
        }


        public void setNumerator(int n) {
           this.numerator = n;

        }


        public int getDenominator() {
            return denominator;
        }


        public void setDenominator(int d) {
        this.denominator = d;
        this.reduce();
        }

        public Fraction add(Fraction x)
        {
        int newNum = (this.numerator * x.denominator) + (x.numerator * this.denominator);
        int newDen = this.denominator * x.denominator;
        return new Fraction(newNum, newDen);
        }

        public Fraction subtract(Fraction x)
        {
        int newNum = (this.numerator * x.denominator) - (x.numerator * this.denominator);
        int newDen = this.denominator * x.denominator;
        return new Fraction(newNum, newDen);
        }
public Fraction multiply(Fraction x)
        {
        int newNum = this.numerator * x.numerator;
        int newDen = this.denominator * x.denominator;
        return new Fraction(newNum, newDen);
        }

        public Fraction divide(Fraction x)
        {
        int newNum = this.numerator * x.denominator;
        int newDen = this.denominator * x.numerator;
        return new Fraction(newNum, newDen);
        }

        public String toString()
        {

            return numerator + "/" + denominator;
        }

       private int gcd(int int1, int int2)
       {
          int smallest;
           if(int1>int2){
              smallest = int2;
           }
           else{
              smallest = int1;
           }
           int i;
           for(i = smallest; i>1; i--){
              if((int1%i==0) && (int2%i==0)){
                 return i;
              }
           }
           return 0;
       }

       private Fraction reduce() {
        int gcdNum = gcd(Math.abs(this.numerator), Math.abs(this.denominator));
        if(gcdNum>0){
        this.numerator = this.numerator / gcdNum;
        this.denominator = this.denominator / gcdNum;
        }
        if((this.numerator<0)&&(this.denominator<0)){
            this.numerator = this.numerator-1;
            this.denominator = this.denominator-1;
        }
        if((this.numerator>0)&&(this.denominator<0)){
            this.numerator = this.numerator-1;
            this.denominator = this.denominator-1;
        }
        if (this.numerator==0){
            this.denominator = 1;
        }
        return this; 
    }
private double trueValue(){
           double x = (double) this.numerator;
           double y = (double) this.denominator;
           return x/y;
       }

       public int compareTo(Fraction x){

           if(this.trueValue()>x.trueValue())return 1;
           if(this.trueValue()<x.trueValue()) return -1;
           else return 0;

       }
}
