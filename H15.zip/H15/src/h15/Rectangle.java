/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package h15;

/**
 *
 * @author Rodrigo Mozo Jr
 */
public class Rectangle implements Comparable <Rectangle> {
    private double length;
    private double width;
    private double peri;
    private double area;
    
    //default constructor
    public Rectangle(){
    length =0;
    width =0;
    peri=0;
    area=0;
    }
    //create rectangle with two para
    public Rectangle(double l, double w){
    length =l;
    width =w;
    }
    
    public double perimeter(){
       peri = length*width;
       return peri;
    }
    
    public double area(){
        area = length*width;
        return area;
    }
    
    public String toString(){
        return "Length: " + length + "ft Width: " + width+ "ft Area: "+ area() +" square Inch Perimeter: "+perimeter()+"ft";
    }
    
    public int compareTo(Rectangle x){

           if(this.area()>x.area())return 1;
           if(this.area()<x.area()) return -1;
           else return 0;

       }
            
       
}
